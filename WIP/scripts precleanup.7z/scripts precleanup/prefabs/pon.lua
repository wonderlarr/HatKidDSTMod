local assets =
{
    Asset("ANIM", "anim/pon.zip"),

    Asset("ATLAS", "images/inventoryimages/pon.xml"),
    Asset("IMAGE", "images/inventoryimages/pon.tex"),
}

RegisterInventoryItemAtlas("images/inventoryimages/pon.xml","pon.tex")


local function OnPickup(inst)
	print("We've been picked up!")
end

local function fn()
  
    local inst = CreateEntity()
 
    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddNetwork()
	inst.entity:AddMiniMapEntity()
     
    MakeInventoryPhysics(inst)   
      
    inst.AnimState:SetBank("pon")
    inst.AnimState:SetBuild("pon")
    inst.AnimState:PlayAnimation("idle")
	
    if not TheWorld.ismastersim then
        return inst
    end
 
    inst.entity:SetPristine()

	inst:AddComponent("stackable")
	inst.components.stackable.maxsize = TUNING.STACK_SIZE_SMALLITEM
  
    inst:AddComponent("inspectable")

    inst:AddComponent("inventoryitem")
    -- inst.components.inventoryitem.imagename = "pon"
    -- inst.components.inventoryitem.atlasname = "images/inventoryimages/pon.xml"
	inst.components.inventoryitem:SetOnPickupFn(OnPickup)


	
	MakeHauntableLaunch(inst)
	
    return inst
end

STRINGS.NAMES.PON = "Pon"
STRINGS.CHARACTERS.GENERIC.DESCRIBE.PON = "Ooo, shiny!"
STRINGS.RECIPE_DESC.PON = "A green collectable, used for... something?"

return  Prefab("pon", fn, assets) 